/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Ritish
 */
public class Test1 {
    public static void main(String[] args) {
        int []a = {1,2,3,4,5,6};
        int i = a.length;
        while(i>=1){
            System.out.println(a[i]);
            i--;
        }
    }
}


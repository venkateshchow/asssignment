/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.Arrays;


/**
 *
 * @author Ritish
 */
public class Ex6 {
    public static void main(String[] args) {
        int i=0, j=0;
        try{
            j/=i;
        }
        catch(Exception e){
            System.out.println("error");
        }

    }
}
